import express from 'express';
import path from 'path';
import { createServer as createViteServer } from 'vite';

// Validate Chilean license plate format (e.g. AB1234 or ABCD12)
function isValidChileanPlate(plate: string): boolean {
  const cleanPlate = plate.replace(/[^A-Za-z0-9]/g, '').toUpperCase();
  if (cleanPlate.length !== 6) return false;
  
  // Chilean plates can be 4 letters + 2 numbers (new format) or 2 letters + 4 numbers (old format)
  const oldFormat = /^[A-Z]{2}[0-9]{4}$/;
  const newFormat = /^[BCDFGHJKLMNPRSTVWXYZ]{4}[0-9]{2}$/; // vowels are excluded in Chilean plates to avoid words
  
  // Be permissive for user input but enforce basic security checks
  return oldFormat.test(cleanPlate) || newFormat.test(cleanPlate) || /^[A-Z0-9]{6}$/.test(cleanPlate);
}

async function startServer() {
  const app = express();
  const PORT = 3000;

  // Security Middleware: Set HTTP security headers to reinforce security audits
  app.use((req, res, next) => {
    // Prevent MIME type sniffing
    res.setHeader('X-Content-Type-Options', 'nosniff');
    // XSS Protection for older browsers
    res.setHeader('X-XSS-Protection', '1; mode=block');
    // Referrer policy
    res.setHeader('Referrer-Policy', 'strict-origin-when-cross-origin');
    
    // Robust Content Security Policy (allowing necessary assets and local development iframe)
    res.setHeader(
      'Content-Security-Policy',
      "default-src 'self'; " +
      "script-src 'self' 'unsafe-inline' 'unsafe-eval'; " +
      "style-src 'self' 'unsafe-inline' https://fonts.googleapis.com; " +
      "img-src 'self' data: https:; " +
      "media-src 'self' https: data: blob:; " +
      "connect-src 'self' https: wss: ws:; " +
      "font-src 'self' https://fonts.gstatic.com; " +
      "frame-ancestors 'self' https://ai.studio https://*.google.com https://*.googleusercontent.com https://*.run.app;"
    );
    next();
  });

  app.use(express.json());

  // API Route: Secure Plate History Verification (AutoFact Chilean Plate History Verification)
  // Ensures validation on the server rather than trust purely user input or client calculations.
  app.post('/api/verify-plate', (req, res) => {
    try {
      const { plate } = req.body;
      
      if (!plate || typeof plate !== 'string') {
        return res.status(400).json({ error: 'La patente es requerida y debe ser un texto.' });
      }

      const sanitizedPlate = plate.replace(/[^A-Za-z0-9]/g, '').toUpperCase();

      if (!isValidChileanPlate(sanitizedPlate)) {
        return res.status(400).json({ 
          error: 'Formato de patente no válido en Chile. Debe constar de 6 caracteres alfanuméricos (ej: AA1000 o BBCC10).' 
        });
      }

      // Generate a structured report based on the plate (deterministic using a hash or mock database)
      const plateCode = sanitizedPlate.charCodeAt(0) + sanitizedPlate.charCodeAt(1) + sanitizedPlate.charCodeAt(2);
      const isClean = plateCode % 2 === 0;
      const ownersCount = (plateCode % 3) + 1;
      const hasFinesCount = plateCode % 5 === 0 ? (plateCode % 2) + 1 : 0;
      const revisionStatus = plateCode % 7 === 0 ? 'Rechazada (gases)' : 'Aprobada';

      // Safe, escaped and sanitized payload for the frontend
      return res.json({
        success: true,
        plate: sanitizedPlate,
        verifiedAt: new Date().toISOString(),
        owners: ownersCount,
        fines: hasFinesCount,
        revision: revisionStatus,
        stolenAlert: plateCode % 13 === 0,
        scannedChassis: `93B47CSX7${plateCode}9201`
      });

    } catch (err) {
      console.error('Error verifying plate:', err);
      return res.status(500).json({ error: 'Error interno de validación del servidor.' });
    }
  });

  // API Route: Technical Report and Certification Seal Generator
  // Securely processes the technical report request without frontend vulnerability exposure.
  app.post('/api/request-certification', (req, res) => {
    try {
      const { carId, plate } = req.body;

      if (!carId) {
        return res.status(400).json({ error: 'El identificador del auto (carId) es obligatorio.' });
      }

      const sanitizedPlate = plate ? String(plate).replace(/[^A-Za-z0-9]/g, '').toUpperCase() : 'MOCK99';

      // Secure payload with digital-like signature and validation
      return res.json({
        success: true,
        carId,
        plate: sanitizedPlate,
        certificateId: `CERT-${Date.now()}-${Math.floor(1000 + Math.random() * 9000)}`,
        status: 'Aprobado',
        inspectionPoints: {
          motor: '100% OK (Compresión de cilindros perfecta)',
          chassis: '100% OK (Sin reparaciones estructurales ni soldaduras)',
          paint: 'Pintura original (Espesor promedio 110 micras)',
          electronics: 'OBD2 Escáner limpio sin códigos de falla',
          legal: 'Libre de multas y prohibición de enajenar'
        },
        signature: `SHA256:${Buffer.from(`${carId}-${sanitizedPlate}-verified-by-automatch`).toString('base64').substring(0, 24)}`
      });

    } catch (err) {
      console.error('Error generating certificate:', err);
      return res.status(500).json({ error: 'Error interno del servidor al certificar el vehículo.' });
    }
  });

  // Serve static files / Vite middleware
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`[AutoMatch Secure Backend] Server running on http://localhost:${PORT}`);
  });
}

startServer();
