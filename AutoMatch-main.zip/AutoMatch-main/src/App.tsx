import React, { useState, useEffect, useCallback } from 'react';
import { Car, Match, Message, UserCar } from './types';
import { MOCK_CARS } from './mockData';
import Onboarding from './components/Onboarding';
import SwipeDeck from './components/SwipeDeck';
import ChatSection from './components/ChatSection';
import Dashboard from './components/Dashboard';
import MatchCelebration from './components/MatchCelebration';
import CarCard from './components/CarCard'; // For single detail card popups
import { 
  Car as CarIcon, 
  CarFront,
  Heart, 
  MessageCircle, 
  User, 
  Sparkles, 
  TrendingUp, 
  RotateCcw, 
  X, 
  ShieldCheck, 
  Trash2,
  Info,
  Volume2,
  Key
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { playEngineSound, EngineType } from './lib/audio';

export default function App() {
  // Onboarding & Profile State
  const [userCar, setUserCar] = useState<UserCar | null>(null);
  const [userName, setUserName] = useState<string>('');
  const [isLoaded, setIsLoaded] = useState(false);

  // Tab State: 'swipe', 'chats', 'dashboard'
  const [activeTab, setActiveTab] = useState<'swipe' | 'chats' | 'dashboard'>('swipe');

  // Swiped & Match States
  const [swipedCarIds, setSwipedCarIds] = useState<string[]>([]);
  const [matches, setMatches] = useState<Match[]>([]);
  const [isBoosted, setIsBoosted] = useState<boolean>(false);

  // Celebration state
  const [celebrationOpen, setCelebrationOpen] = useState(false);
  const [celebratedCar, setCelebratedCar] = useState<Car | null>(null);
  
  // Navigation Helper inside chat
  const [activeMatchId, setActiveMatchId] = useState<string | null>(null);

  // Ficha/Detail dialog for popup view from chat or stats
  const [detailCar, setDetailCar] = useState<Car | null>(null);

  // Load from LocalStorage
  useEffect(() => {
    const storedUserCar = localStorage.getItem('automatch_user_car');
    const storedUserName = localStorage.getItem('automatch_user_name');
    const storedSwiped = localStorage.getItem('automatch_swiped_ids');
    const storedMatches = localStorage.getItem('automatch_matches');
    const storedBoosted = localStorage.getItem('automatch_boosted');

    if (storedUserCar && storedUserName) {
      setUserCar(JSON.parse(storedUserCar));
      setUserName(storedUserName);
    }
    if (storedSwiped) {
      setSwipedCarIds(JSON.parse(storedSwiped));
    }
    if (storedMatches) {
      setMatches(JSON.parse(storedMatches));
    } else {
      // Seed a default welcoming match to show clients how it works!
      // We will match them with Andrés and his Suzuki Swift Sport as a starter match!
      const defaultCar = MOCK_CARS[0];
      const initialMatch: Match = {
        id: defaultCar.id,
        car: defaultCar,
        timestamp: new Date().toLocaleTimeString('es-CL', { hour: '2-digit', minute: '2-digit' }),
        unread: true,
        messages: [
          {
            id: 'system_init',
            sender: 'other',
            text: `[Sistema] ¡Es un AutoMatch! Ambos están interesados. Andrés busca: "${defaultCar.permutaPreferences}"`,
            timestamp: new Date().toLocaleTimeString('es-CL', { hour: '2-digit', minute: '2-digit' })
          },
          {
            id: 'init_msg_1',
            sender: 'other',
            text: defaultCar.chatPersona?.greeting || '¡Hola! Vi tu auto y me interesó harto para permuta. ¿Buscas permutar o vender?',
            timestamp: new Date().toLocaleTimeString('es-CL', { hour: '2-digit', minute: '2-digit' })
          }
        ]
      };
      setMatches([initialMatch]);
      localStorage.setItem('automatch_matches', JSON.stringify([initialMatch]));
    }
    if (storedBoosted) {
      setIsBoosted(JSON.parse(storedBoosted));
    }

    setIsLoaded(true);
  }, []);

  // Play startup engine sound on the very first user interaction with the page
  useEffect(() => {
    let triggered = false;
    const handleFirstGesture = () => {
      if (triggered) return;
      triggered = true;
      
      const savedSound = (localStorage.getItem('automatch_engine_sound') as EngineType) || 'v8';
      playEngineSound(savedSound);
      
      // Remove listeners so it only triggers once per app lifecycle load
      window.removeEventListener('click', handleFirstGesture);
      window.removeEventListener('keydown', handleFirstGesture);
      window.removeEventListener('touchstart', handleFirstGesture);
    };

    window.addEventListener('click', handleFirstGesture);
    window.addEventListener('keydown', handleFirstGesture);
    window.addEventListener('touchstart', handleFirstGesture);

    return () => {
      window.removeEventListener('click', handleFirstGesture);
      window.removeEventListener('keydown', handleFirstGesture);
      window.removeEventListener('touchstart', handleFirstGesture);
    };
  }, []);

  // Save to LocalStorage
  const saveToStorage = (key: string, value: any) => {
    localStorage.setItem(key, JSON.stringify(value));
  };

  const handleOnboardingComplete = (car: UserCar, name: string) => {
    setUserCar(car);
    setUserName(name);
    localStorage.setItem('automatch_user_car', JSON.stringify(car));
    localStorage.setItem('automatch_user_name', name);
  };

  // Triggered when user swipes Right (Like) or Up (Super Like)
  const handleSwipeAction = (car: Car, type: 'like' | 'superlike') => {
    // Save as swiped
    const updatedSwiped = [...swipedCarIds, car.id];
    setSwipedCarIds(updatedSwiped);
    saveToStorage('automatch_swiped_ids', updatedSwiped);

    // 40% chance of Match if car likes user, OR 100% chance if Super Like or car is preset to like
    const isMatch = car.likesUser || type === 'superlike';

    if (isMatch) {
      // Add a small delay to simulate real human feedback
      setTimeout(() => {
        const newMatch: Match = {
          id: car.id,
          car,
          timestamp: new Date().toLocaleTimeString('es-CL', { hour: '2-digit', minute: '2-digit' }),
          unread: true,
          messages: [
            {
              id: `sys_${Date.now()}`,
              sender: 'other',
              text: `[Sistema] ¡Felicidades, es un AutoMatch! Has conectado con ${car.ownerName} para negociar.`,
              timestamp: new Date().toLocaleTimeString('es-CL', { hour: '2-digit', minute: '2-digit' })
            },
            {
              id: `msg_${Date.now()}`,
              sender: 'other',
              text: car.chatPersona?.greeting || `¡Hola! Me encantó tu publicación. ¿Hablemos de negocios?`,
              timestamp: new Date().toLocaleTimeString('es-CL', { hour: '2-digit', minute: '2-digit' })
            }
          ]
        };

        // Update matches state & save
        const updatedMatches = [newMatch, ...matches.filter(m => m.id !== car.id)];
        setMatches(updatedMatches);
        saveToStorage('automatch_matches', updatedMatches);

        // Pop up the celebration screen & play notification engine sound!
        setCelebratedCar(car);
        setCelebrationOpen(true);
        playConfiguredEngineSound();
      }, 600);
    }
  };

  const handleSwipeLeft = (car: Car) => {
    const updatedSwiped = [...swipedCarIds, car.id];
    setSwipedCarIds(updatedSwiped);
    saveToStorage('automatch_swiped_ids', updatedSwiped);
  };

  const handleSwipeRight = (car: Car) => {
    handleSwipeAction(car, 'like');
  };

  const handleSwipeUp = (car: Car) => {
    handleSwipeAction(car, 'superlike');
  };

  // Chat actions
  const handleSendMessage = (
    matchId: string, 
    text: string, 
    sender: 'user' | 'other',
    mediaType?: 'photo' | 'video',
    mediaUrl?: string,
    callDuration?: string,
    isCallMessage?: boolean
  ) => {
    const updatedMatches = matches.map(match => {
      if (match.id === matchId) {
        const newMsg: Message = {
          id: `${sender}_${Date.now()}`,
          sender,
          text,
          timestamp: new Date().toLocaleTimeString('es-CL', { hour: '2-digit', minute: '2-digit' }),
          mediaType,
          mediaUrl,
          callDuration,
          isCallMessage
        };
        return {
          ...match,
          timestamp: newMsg.timestamp,
          unread: sender === 'other' && matchId !== activeMatchId, // mark unread only if other is sender and user is not looking
          messages: [...match.messages, newMsg]
        };
      }
      return match;
    });

    setMatches(updatedMatches);
    saveToStorage('automatch_matches', updatedMatches);
  };

  const handleMarkRead = (matchId: string) => {
    const updatedMatches = matches.map(match => {
      if (match.id === matchId) {
        return { ...match, unread: false };
      }
      return match;
    });
    setMatches(updatedMatches);
    saveToStorage('automatch_matches', updatedMatches);
  };

  const handleUpdateCar = (updatedCar: UserCar) => {
    setUserCar(updatedCar);
    saveToStorage('automatch_user_car', updatedCar);
  };

  // Reset swiped list to test again
  const handleResetDeck = () => {
    setSwipedCarIds([]);
    saveToStorage('automatch_swiped_ids', []);
  };

  // Boost simulated premium feature
  const handleBoost = () => {
    setIsBoosted(true);
    saveToStorage('automatch_boosted', true);

    // Simulate getting an instant Match when boosted!
    setTimeout(() => {
      // Find a car that isn't already matched
      const unmatched = MOCK_CARS.filter(c => !matches.some(m => m.id === c.id));
      const randomCar = unmatched.length > 0 ? unmatched[Math.floor(Math.random() * unmatched.length)] : MOCK_CARS[1];

      const newMatch: Match = {
        id: randomCar.id,
        car: randomCar,
        timestamp: new Date().toLocaleTimeString('es-CL', { hour: '2-digit', minute: '2-digit' }),
        unread: true,
        messages: [
          {
            id: `sys_boost_${Date.now()}`,
            sender: 'other',
            text: `[Sistema Boost] ¡Un cliente Premium ha hecho Match contigo!`,
            timestamp: new Date().toLocaleTimeString('es-CL', { hour: '2-digit', minute: '2-digit' })
          },
          {
            id: `msg_boost_${Date.now()}`,
            sender: 'other',
            text: `¡Hola! Me apareció tu auto destacado. Me interesa caleta permutar mi ${randomCar.brand} ${randomCar.model} por el tuyo. ¿Te tinca conversar?`,
            timestamp: new Date().toLocaleTimeString('es-CL', { hour: '2-digit', minute: '2-digit' })
          }
        ]
      };

      const updatedMatches = [newMatch, ...matches.filter(m => m.id !== randomCar.id)];
      setMatches(updatedMatches);
      saveToStorage('automatch_matches', updatedMatches);

      // Trigger Celebration & play notification engine sound!
      setCelebratedCar(randomCar);
      setCelebrationOpen(true);
      playConfiguredEngineSound();
    }, 4000);
  };

  // Clear all saved data to start over completely
  const handleHardReset = () => {
    if (confirm('¿Estás seguro de reiniciar todo? Se borrarán tus datos de auto publicado y tus chats.')) {
      localStorage.clear();
      setUserCar(null);
      setUserName('');
      setSwipedCarIds([]);
      setMatches([]);
      setIsBoosted(false);
      setActiveTab('swipe');
      setActiveMatchId(null);
      setDetailCar(null);
    }
  };

  const playConfiguredEngineSound = () => {
    const savedSound = (localStorage.getItem('automatch_engine_sound') as EngineType) || 'v8';
    playEngineSound(savedSound);
  };

  // Filter cars to show in SwipeDeck (exclude swiped cars)
  const remainingCars = MOCK_CARS.filter(car => !swipedCarIds.includes(car.id));

  // Count total unread chats
  const unreadCount = matches.filter(m => m.unread).length;

  if (!isLoaded) {
    return (
      <div className="min-h-screen bg-[#0a0a0a] flex items-center justify-center font-sans text-white/70">
        <div className="text-center space-y-4">
          <div className="w-12 h-12 border-4 border-red-600 border-t-transparent rounded-full animate-spin mx-auto"></div>
          <p className="font-bold text-sm tracking-widest uppercase">Cargando AutoMatch Chile...</p>
        </div>
      </div>
    );
  }

  // If no user car is set up, show beautiful Onboarding / Valuation first
  if (!userCar) {
    return <Onboarding onComplete={handleOnboardingComplete} />;
  }

  return (
    <div className="h-screen h-[100dvh] overflow-hidden bg-[#0a0a0a] text-white flex flex-col justify-between" id="app_root_layout">
      
      {/* HEADER BAR (Responsive & Elegant) */}
      <header className="bg-[#0f0f0f] border-b border-white/10 py-4 px-4 md:px-8 flex items-center justify-between sticky top-0 z-30 shrink-0" id="main_header">
        <div className="flex items-center gap-2">
          <div className="w-10 h-10 bg-gradient-to-tr from-red-700 via-red-600 to-rose-600 rounded-xl flex items-center justify-center rotate-3 shadow-lg shadow-red-600/50 hover:rotate-6 active:scale-95 transition-all duration-300 shrink-0 border border-red-500/30">
            <CarFront className="w-5.5 h-5.5 text-white fill-white/20 drop-shadow-[0_0_8px_rgba(239,68,68,0.65)] animate-pulse" />
          </div>
          <div className="text-left ml-1">
            <h1 className="font-sans font-black text-xl tracking-tighter leading-none italic uppercase text-white">
              AutoMatch
            </h1>
            <span className="text-[9px] bg-white/10 text-white/60 font-semibold tracking-widest uppercase px-1.5 py-0.5 rounded-full mt-0.5 inline-block">CHILE EDITION</span>
          </div>
        </div>

        {/* Navigation Tabs (Desktop mode) */}
        <nav className="hidden md:flex items-center bg-[#141414] p-1 rounded-xl border border-white/10" id="desktop_tabs">
          <button
            onClick={() => setActiveTab('swipe')}
            className={`py-2 px-4 rounded-lg text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer ${
              activeTab === 'swipe' 
                ? 'bg-red-600 text-white shadow-md shadow-red-600/20' 
                : 'text-white/60 hover:text-white hover:bg-white/5'
            }`}
            id="tab_swipe_desktop"
          >
            <CarIcon className="w-4 h-4" />
            Deslizar Autos
            {remainingCars.length > 0 && (
              <span className="bg-white text-red-600 text-[9px] font-black px-1.5 py-0.5 rounded-full">
                {remainingCars.length}
              </span>
            )}
          </button>

          <button
            onClick={() => setActiveTab('chats')}
            className={`py-2 px-4 rounded-lg text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer relative ${
              activeTab === 'chats' 
                ? 'bg-red-600 text-white shadow-md shadow-red-600/20' 
                : 'text-white/60 hover:text-white hover:bg-white/5'
            }`}
            id="tab_chats_desktop"
          >
            <MessageCircle className="w-4 h-4" />
            Chats de Negociación
            {unreadCount > 0 && (
              <span className="bg-white text-red-600 text-[9px] font-black px-1.5 py-0.5 rounded-full">
                {unreadCount}
              </span>
            )}
          </button>

          <button
            onClick={() => setActiveTab('dashboard')}
            className={`py-2 px-4 rounded-lg text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer ${
              activeTab === 'dashboard' 
                ? 'bg-red-600 text-white shadow-md shadow-red-600/20' 
                : 'text-white/60 hover:text-white hover:bg-white/5'
            }`}
            id="tab_dashboard_desktop"
          >
            <TrendingUp className="w-4 h-4" />
            Mi Publicación
          </button>
        </nav>

        {/* User profile capsule info */}
        <div className="flex items-center gap-3">
          <div className="hidden sm:flex flex-col text-right">
            <span className="text-xs font-bold text-white/90">{userName}</span>
            <span className="text-[10px] text-white/50 truncate w-32 font-mono">
              {userCar.brand} {userCar.model} ({userCar.year})
            </span>
          </div>
          
          {/* 🔊 ENGINE START SOUND ACTION (REV/STARTUP TRIGGER) */}
          <button
            onClick={playConfiguredEngineSound}
            className="flex items-center gap-1.5 px-2.5 py-1.5 bg-red-600/10 hover:bg-red-600/20 text-red-500 hover:text-red-400 border border-red-500/20 hover:border-red-500/40 rounded-xl text-xs font-black uppercase transition-all duration-300 cursor-pointer shadow-lg shadow-red-950/30 shrink-0"
            title="Arrancar motor y escuchar sonido de notificación de la app 🔊"
            id="header_engine_start_btn"
          >
            <Key className="w-3.5 h-3.5 animate-bounce" style={{ animationDuration: '3s' }} />
            <span className="hidden sm:inline text-[9px] tracking-wider">Arrancar 🔊</span>
          </button>

          <button 
            onClick={() => setActiveTab('dashboard')} 
            className="w-9 h-9 rounded-xl overflow-hidden border border-white/10 cursor-pointer shadow-md hover:scale-105 hover:border-red-500 transition-all shrink-0"
            title="Ver tu publicación"
            id="user_avatar_btn"
          >
            <img 
              src={userCar.image} 
              alt="Tu auto" 
              className="w-full h-full object-cover"
              referrerPolicy="no-referrer"
            />
          </button>

          {/* Hard reset button for developers/testers */}
          <button
            onClick={handleHardReset}
            className="text-white/40 hover:text-red-500 p-2 rounded-xl hover:bg-white/5 transition-all cursor-pointer"
            title="Borrar datos y empezar de nuevo"
            id="hard_reset_btn"
          >
            <Trash2 className="w-4 h-4" />
          </button>
        </div>
      </header>

      {/* MAIN CONTAINER CONTENT */}
      <main className="flex-1 w-full bg-[#0a0a0a] flex flex-col min-h-0" id="main_content_area">
        <AnimatePresence mode="wait">
          <motion.div
            key={activeTab}
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            transition={{ duration: 0.15 }}
            className={`flex-1 flex flex-col min-h-0 ${activeTab === 'swipe' ? 'justify-center' : 'justify-start'} ${activeTab !== 'chats' ? 'overflow-y-auto' : 'overflow-hidden'}`}
            id={`tab_pane_${activeTab}`}
          >
            {activeTab === 'swipe' && (
              <SwipeDeck
                cars={remainingCars}
                onSwipeLeft={handleSwipeLeft}
                onSwipeRight={handleSwipeRight}
                onSwipeUp={handleSwipeUp}
                onReset={handleResetDeck}
                onBoost={handleBoost}
                isBoosted={isBoosted}
              />
            )}

            {activeTab === 'chats' && (
              <ChatSection
                matches={matches}
                userCar={userCar}
                onSendMessage={handleSendMessage}
                onMarkRead={handleMarkRead}
                activeMatchId={activeMatchId}
                setActiveMatchId={setActiveMatchId}
                onOpenCarDetails={(car) => setDetailCar(car)}
              />
            )}

            {activeTab === 'dashboard' && (
              <Dashboard
                userCar={userCar}
                onUpdateCar={handleUpdateCar}
                onBoost={handleBoost}
                isBoosted={isBoosted}
              />
            )}
          </motion.div>
        </AnimatePresence>
      </main>

      {/* FOOTER NAVIGATION TABS (Mobile mode sticky bottom) */}
      <footer className="bg-[#0f0f0f] border-t border-white/10 py-2 px-3 md:hidden sticky bottom-0 z-30 shrink-0 shadow-xl" id="mobile_navbar">
        <div className="grid grid-cols-3 gap-1">
          
          <button
            onClick={() => setActiveTab('swipe')}
            className={`flex flex-col items-center justify-center py-1.5 rounded-xl transition-all cursor-pointer ${
              activeTab === 'swipe' ? 'text-red-500 bg-red-600/10' : 'text-white/50 hover:text-white/80'
            }`}
            id="tab_swipe_mobile"
          >
            <div className="relative">
              <CarIcon className="w-5 h-5" />
              {remainingCars.length > 0 && (
                <span className="absolute -top-1.5 -right-2 bg-red-600 text-white text-[8px] font-bold px-1.5 py-0.2 rounded-full min-w-[14px] text-center">
                  {remainingCars.length}
                </span>
              )}
            </div>
            <span className="text-[10px] font-bold mt-1">Deslizar</span>
          </button>

          <button
            onClick={() => setActiveTab('chats')}
            className={`flex flex-col items-center justify-center py-1.5 rounded-xl transition-all cursor-pointer ${
              activeTab === 'chats' ? 'text-red-500 bg-red-600/10' : 'text-white/50 hover:text-white/80'
            }`}
            id="tab_chats_mobile"
          >
            <div className="relative">
              <MessageCircle className="w-5 h-5" />
              {unreadCount > 0 && (
                <span className="absolute -top-1.5 -right-2.5 bg-red-600 text-white text-[8px] font-bold px-1.5 py-0.2 rounded-full min-w-[14px] text-center">
                  {unreadCount}
                </span>
              )}
            </div>
            <span className="text-[10px] font-bold mt-1">Chats</span>
          </button>

          <button
            onClick={() => setActiveTab('dashboard')}
            className={`flex flex-col items-center justify-center py-1.5 rounded-xl transition-all cursor-pointer ${
              activeTab === 'dashboard' ? 'text-red-500 bg-red-600/10' : 'text-white/50 hover:text-white/80'
            }`}
            id="tab_dashboard_mobile"
          >
            <TrendingUp className="w-5 h-5" />
            <span className="text-[10px] font-bold mt-1">Mi Publicación</span>
          </button>

        </div>
      </footer>

      {/* CELEBRATION FULLSCREEN DIALOG MATCH */}
      <MatchCelebration
        isOpen={celebrationOpen}
        userCar={userCar}
        matchedCar={celebratedCar}
        onClose={() => setCelebrationOpen(false)}
        onGoToChat={() => {
          setCelebrationOpen(false);
          setActiveTab('chats');
          if (celebratedCar) {
            setActiveMatchId(celebratedCar.id);
          }
        }}
      />

      {/* LIGHTBOX FOR SINGLE CAR DETAILS POPUPS (From Ficha click in Chat) */}
      <AnimatePresence>
        {detailCar && (
          <div className="fixed inset-0 bg-black/85 z-50 flex items-center justify-center p-4 backdrop-blur-md" id="detail_lightbox_backdrop">
            <motion.div 
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              className="relative max-w-md w-full bg-[#141414] border border-white/10 rounded-3xl h-[600px] overflow-hidden"
              id="detail_lightbox_card"
            >
              <CarCard
                car={detailCar}
                index={0}
                active={true}
                onSwipeLeft={() => setDetailCar(null)}
                onSwipeRight={() => setDetailCar(null)}
                onSwipeUp={() => setDetailCar(null)}
              />
              {/* Back to chat overlay action */}
              <button
                onClick={() => setDetailCar(null)}
                className="absolute top-4 right-4 z-50 bg-black/60 hover:bg-red-600 text-white p-2 rounded-full cursor-pointer transition-all"
                id="close_lightbox_btn"
              >
                <X className="w-5 h-5" />
              </button>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

    </div>
  );
}
