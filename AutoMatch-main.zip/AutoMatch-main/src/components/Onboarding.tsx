import React, { useState, useEffect } from 'react';
import { UserCar, ValuationResult } from '../types';
import { POPULAR_BRANDS, CHILEAN_REGIONS, estimateCarValue } from '../mockData';
import { 
  Car as CarIcon, 
  CarFront, 
  Sparkles, 
  ShieldCheck, 
  MapPin, 
  DollarSign, 
  ArrowRight, 
  TrendingUp, 
  Compass, 
  Heart,
  Volume2,
  Zap,
  Key,
  Upload,
  ImagePlus
} from 'lucide-react';
import { motion } from 'motion/react';
import { playEngineSound, EngineType } from '../lib/audio';

interface OnboardingProps {
  onComplete: (userCar: UserCar, userName: string) => void;
}

// Preset photos for user's car to look beautiful
const PHOTO_PRESETS = [
  { id: 'hatchback', name: 'Hatchback Deportivo (Rojo)', url: 'https://images.unsplash.com/photo-1511919884226-fd3cad34687c?auto=format&fit=crop&q=80&w=800' },
  { id: 'sedan', name: 'Sedán Elegante (Plateado)', url: 'https://images.unsplash.com/photo-1555215695-3004980ad54e?auto=format&fit=crop&q=80&w=800' },
  { id: 'suv', name: 'SUV Familiar (Blanco)', url: 'https://images.unsplash.com/photo-1617788138017-80ad40651399?auto=format&fit=crop&q=80&w=800' },
  { id: 'pickup', name: 'Camioneta 4x4 (Gris)', url: 'https://images.unsplash.com/photo-1533473359331-0135ef1b58bf?auto=format&fit=crop&q=80&w=800' },
  { id: 'coupe', name: 'Deportivo Premium (Azul)', url: 'https://images.unsplash.com/photo-1494976388531-d1058494cdd8?auto=format&fit=crop&q=80&w=800' }
];

export default function Onboarding({ onComplete }: OnboardingProps) {
  const [step, setStep] = useState<0 | 1 | 2 | 3>(0); // 0: Welcome, 1: Valuation & Car Info, 2: Swap/Sell Prefs, 3: Contact & Presets

  // Form State
  const [brand, setBrand] = useState('Suzuki');
  const [model, setModel] = useState('Swift');
  const [year, setYear] = useState(2019);
  const [km, setKm] = useState(60000);
  const [fuel, setFuel] = useState<'Bencina' | 'Diésel' | 'Híbrido' | 'Eléctrico'>('Bencina');
  const [transmission, setTransmission] = useState<'Manual' | 'Automática'>('Manual');
  const [price, setPrice] = useState(9500000);
  
  // Business State
  const [permuta, setPermuta] = useState(true);
  const [permutaPreferences, setPermutaPreferences] = useState('Busco SUV o camioneta, pago diferencia.');
  const [description, setDescription] = useState('Excelente estado, único dueño, mantenciones al día, papeles listos para transferir.');
  
  // Contact & Image State
  const [selectedPhoto, setSelectedPhoto] = useState(PHOTO_PRESETS[0].url);
  const [isUploadedPhoto, setIsUploadedPhoto] = useState(false);
  const [uploadError, setUploadError] = useState('');
  const [userName, setUserName] = useState('');
  const [contactPhone, setContactPhone] = useState('+56 9 ');
  const [region, setRegion] = useState('Región Metropolitana');
  const [commune, setCommune] = useState('Santiago');

  // Valuation results
  const [valuation, setValuation] = useState<ValuationResult | null>(null);

  // Engine Sound Settings State
  const [selectedEngineSound, setSelectedEngineSound] = useState<EngineType>(() => {
    const saved = localStorage.getItem('automatch_engine_sound');
    return (saved as EngineType) || 'v8';
  });

  // Auto-fill presets to quickly test
  const handleQuickFill = (brandName: string, modelName: string, yearVal: number, kmVal: number, priceVal: number, photoId: string) => {
    setBrand(brandName);
    setModel(modelName);
    setYear(yearVal);
    setKm(kmVal);
    setPrice(priceVal);
    setStep(1);
    
    const photo = PHOTO_PRESETS.find(p => p.id === photoId);
    if (photo) {
      setSelectedPhoto(photo.url);
      setIsUploadedPhoto(false);
    }
  };

  // Handle photo upload directly from the user's device gallery
  const handlePhotoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setUploadError('');

    if (!file.type.startsWith('image/')) {
      setUploadError('Por favor sube un archivo de imagen válido (JPG, PNG, WEBP).');
      return;
    }

    // Limit to 8MB to keep things snappy and within LocalStorage limits
    const maxSizeBytes = 8 * 1024 * 1024;
    if (file.size > maxSizeBytes) {
      setUploadError('La imagen es muy pesada (máx. 8MB). Prueba con otra foto.');
      return;
    }

    const reader = new FileReader();
    reader.onload = () => {
      if (typeof reader.result === 'string') {
        setSelectedPhoto(reader.result);
        setIsUploadedPhoto(true);
      }
    };
    reader.onerror = () => {
      setUploadError('No pudimos leer la imagen. Intenta con otra foto.');
    };
    reader.readAsDataURL(file);

    // Reset the input value so selecting the same file again still fires onChange
    e.target.value = '';
  };

  // Trigger Valuation whenever Brand, Year, KM changes
  useEffect(() => {
    const res = estimateCarValue({
      brand,
      model,
      year,
      km,
      condition: 'good'
    });
    setValuation(res);
    setPrice(res.avgPrice);
  }, [brand, model, year, km]);

  // Update communes list when region changes
  const activeRegionObj = CHILEAN_REGIONS.find(r => r.name === region);
  const communesList = activeRegionObj ? activeRegionObj.communes : [];

  useEffect(() => {
    if (communesList.length > 0) {
      setCommune(communesList[0]);
    }
  }, [region]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!userName.trim()) return;

    // Persist selected notification / startup engine sound
    localStorage.setItem('automatch_engine_sound', selectedEngineSound);
    
    // Play the satisfying car engine start sound on entry!
    playEngineSound(selectedEngineSound);

    const userCar: UserCar = {
      brand,
      model,
      year,
      km,
      location: `${commune}, ${region === "Región Metropolitana" ? "RM" : region}`,
      fuel,
      transmission,
      price,
      permuta,
      permutaPreferences: permuta ? permutaPreferences : 'No busco permutas, solo venta.',
      description,
      image: selectedPhoto,
      views: Math.floor(Math.random() * 25) + 5,
      likes: Math.floor(Math.random() * 8) + 1,
      superLikes: 0,
      contactPhone: contactPhone || '+56912345678'
    };

    onComplete(userCar, userName);
  };

  return (
    <div className="min-h-screen bg-[#0a0a0a] text-white flex flex-col justify-between" id="onboarding_container">
      {/* Header */}
      <header className="bg-[#0f0f0f] border-b border-white/10 py-4 px-6 flex items-center justify-between sticky top-0 z-30" id="onboarding_header">
        <div className="flex items-center gap-2">
          <div className="w-10 h-10 bg-gradient-to-tr from-red-700 via-red-600 to-rose-600 rounded-xl flex items-center justify-center rotate-3 shadow-lg shadow-red-600/50 hover:rotate-6 active:scale-95 transition-all duration-300 shrink-0 border border-red-500/30">
            <CarFront className="w-5.5 h-5.5 text-white fill-white/20 drop-shadow-[0_0_8px_rgba(239,68,68,0.65)] animate-pulse" />
          </div>
          <div>
            <span className="font-sans font-black text-xl tracking-tighter uppercase italic ml-1 text-white">AutoMatch</span>
            <span className="text-[9px] bg-white/10 text-white/60 font-semibold tracking-widest uppercase px-1.5 py-0.5 rounded-full ml-1">CHILE</span>
          </div>
        </div>
        <div className="text-xs font-mono text-white/50 bg-[#141414] border border-white/10 px-2.5 py-1 rounded-full">
          Est. Tasación CLP
        </div>
      </header>

      {/* Steps Content */}
      <main className="flex-1 max-w-2xl w-full mx-auto p-4 md:p-8 flex items-center justify-center">
        {step === 0 ? (
          /* SPLASH SCREEN */
          <motion.div 
            initial={{ opacity: 0, y: 15 }}
            animate={{ opacity: 1, y: 0 }}
            className="w-full bg-[#141414] rounded-3xl p-6 md:p-10 border border-white/10 shadow-2xl text-center"
            id="welcome_card"
          >
            <div className="inline-flex bg-red-600/10 text-red-500 p-4 rounded-full mb-6">
              <Sparkles className="w-10 h-10" />
            </div>

            <h1 className="text-3xl md:text-4xl font-sans font-black tracking-tighter text-white uppercase italic mb-3">
              ¿Vendes o Permutas tu auto en Chile?
            </h1>
            <p className="text-white/70 mb-8 max-w-md mx-auto text-base">
              ¡Te damos la bienvenida a <strong className="text-red-500 font-semibold">AutoMatch</strong>! El Tinder automotriz donde deslizas para encontrar ofertas perfectas de compra o intercambio en segundos.
            </p>

            {/* Feature Highlights */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-10 text-left">
              <div className="p-4 bg-[#0f0f0f] rounded-2xl border border-white/5 flex gap-3 items-start">
                <div className="bg-red-600/10 text-red-500 p-2 rounded-lg shrink-0 mt-0.5">
                  <Heart className="w-5 h-5 fill-current" />
                </div>
                <div>
                  <h3 className="font-bold text-white text-sm">Fácil de Deslizar</h3>
                  <p className="text-xs text-white/50 mt-0.5">Likes para me interesa, dislikes para pasar. ¡Simple!</p>
                </div>
              </div>
              
              <div className="p-4 bg-[#0f0f0f] rounded-2xl border border-white/5 flex gap-3 items-start">
                <div className="bg-red-600/10 text-red-500 p-2 rounded-lg shrink-0 mt-0.5">
                  <TrendingUp className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="font-bold text-white text-sm">Tasador Inteligente</h3>
                  <p className="text-xs text-white/50 mt-0.5">Calculamos el valor real de tu auto en Chile al instante.</p>
                </div>
              </div>

              <div className="p-4 bg-[#0f0f0f] rounded-2xl border border-white/5 flex gap-3 items-start">
                <div className="bg-red-600/10 text-red-500 p-2 rounded-lg shrink-0 mt-0.5">
                  <ShieldCheck className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="font-bold text-white text-sm">Matches de Permuta</h3>
                  <p className="text-xs text-white/50 mt-0.5">Intercambia tu auto mano a mano o con diferencia de dinero.</p>
                </div>
              </div>
            </div>

            {/* 🔊 MOTOR SOUND SELECTOR (WIDGET COMPONENT) */}
            <div className="mb-8 p-5 bg-[#0f0f0f] rounded-2xl border border-white/5 text-left space-y-4" id="engine_sound_selector_widget">
              <div className="flex items-center gap-2.5">
                <div className="bg-red-500/10 text-red-500 p-2 rounded-xl">
                  <Volume2 className="w-5 h-5 animate-pulse" />
                </div>
                <div>
                  <h4 className="font-bold text-sm text-white flex items-center gap-1.5">
                    Sonido de Notificación & Arranque
                    <span className="bg-red-500/15 text-red-400 text-[9px] font-black uppercase px-1.5 py-0.5 rounded-full">NUEVO</span>
                  </h4>
                  <p className="text-xs text-white/50">Escucha y elige el rugido de motor que sonará al entrar a la app y recibir AutoMatches.</p>
                </div>
              </div>

              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                {[
                  { id: 'v8', name: 'V8 Clásico 🇺🇸', desc: 'Rumble profundo' },
                  { id: 'sport', name: 'Sport Turbo 🇯🇵', desc: 'Soplido ágil' },
                  { id: 'rally', name: 'Rally Pro 🇪🇺', desc: 'Corte agresivo' },
                  { id: 'f1', name: 'F1 V10 🏎️', desc: 'Grito agudo' },
                ].map((motor) => (
                  <button
                    key={motor.id}
                    onClick={() => {
                      setSelectedEngineSound(motor.id as EngineType);
                      playEngineSound(motor.id as EngineType);
                    }}
                    className={`p-3 rounded-xl border text-left transition-all duration-300 group cursor-pointer ${
                      selectedEngineSound === motor.id
                        ? 'bg-red-600/15 border-red-500 shadow-md shadow-red-950/40'
                        : 'bg-white/[0.02] border-white/5 hover:border-white/15'
                    }`}
                    type="button"
                    id={`select_sound_${motor.id}`}
                  >
                    <div className="flex items-center justify-between">
                      <span className={`text-[11px] font-bold block ${
                        selectedEngineSound === motor.id ? 'text-red-400' : 'text-white/80'
                      }`}>
                        {motor.name}
                      </span>
                      <Zap className={`w-3 h-3 transition-transform ${
                        selectedEngineSound === motor.id ? 'text-red-400 scale-110' : 'text-white/25 group-hover:scale-110'
                      }`} />
                    </div>
                    <span className="text-[9px] text-white/40 block mt-0.5 leading-none">
                      {motor.desc}
                    </span>
                  </button>
                ))}
              </div>

              <div className="flex gap-2">
                <button
                  onClick={() => playEngineSound(selectedEngineSound)}
                  className="w-full bg-white/5 hover:bg-white/10 active:scale-[0.98] border border-white/10 hover:border-white/20 transition-all py-3 px-4 rounded-xl text-xs font-bold flex items-center justify-center gap-2 text-white cursor-pointer"
                  type="button"
                  id="test_engine_sound_btn"
                >
                  <Key className="w-4 h-4 text-red-500 animate-[spin_3s_linear_infinite]" />
                  Dar Contacto y Probar Arranque 🔊
                </button>
              </div>
            </div>

            {/* Quick Presets Options */}
            <div className="mb-8 p-5 bg-gradient-to-r from-red-950/40 to-[#0a0a0a] rounded-2xl border border-red-600/15 text-white text-left">
              <span className="text-xs uppercase font-mono tracking-widest text-red-400 font-bold block mb-2">Comienza al Instante (Piloto de Prueba)</span>
              <h4 className="font-bold text-sm mb-3 text-white/90">Elige un perfil rápido de auto chileno para probar la app:</h4>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                <button
                  onClick={() => handleQuickFill('Suzuki', 'Swift', 2019, 58000, 9200000, 'hatchback')}
                  className="flex items-center justify-between text-left bg-white/5 hover:bg-white/10 hover:border-red-500 transition-all p-3 rounded-xl border border-white/10 text-xs font-medium cursor-pointer"
                  id="fill_swift_btn"
                >
                  <div>
                    <p className="font-bold text-white">Suzuki Swift 2019</p>
                    <p className="text-red-400 font-mono">58k km • $9.200.000 CLP</p>
                  </div>
                  <ArrowRight className="w-4 h-4 text-white/50" />
                </button>

                <button
                  onClick={() => handleQuickFill('Mazda', 'CX-5', 2020, 48000, 16800000, 'suv')}
                  className="flex items-center justify-between text-left bg-white/5 hover:bg-white/10 hover:border-red-500 transition-all p-3 rounded-xl border border-white/10 text-xs font-medium cursor-pointer"
                  id="fill_cx5_btn"
                >
                  <div>
                    <p className="font-bold text-white">Mazda CX-5 2020</p>
                    <p className="text-red-400 font-mono">48k km • $16.800.000 CLP</p>
                  </div>
                  <ArrowRight className="w-4 h-4 text-white/50" />
                </button>
              </div>
            </div>

            {/* Manual button */}
            <button
              onClick={() => setStep(1)}
              className="w-full bg-red-600 hover:bg-red-700 transition-all text-white font-bold py-4 px-6 rounded-2xl flex items-center justify-center gap-2 text-base cursor-pointer shadow-lg shadow-red-600/35"
              id="start_manual_btn"
            >
              Publicar mi Auto Manualmente
              <ArrowRight className="w-5 h-5" />
            </button>
          </motion.div>
        ) : step === 1 ? (
          /* PASO 1: CAR INFO & VALUATION */
          <motion.div 
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            className="w-full bg-[#141414] rounded-3xl p-6 md:p-8 border border-white/10 shadow-2xl"
            id="step1_card"
          >
            <div className="flex items-center justify-between mb-6">
              <div>
                <span className="text-xs font-bold text-red-500 uppercase tracking-wider">Paso 1 de 3</span>
                <h2 className="text-2xl font-sans font-black uppercase italic tracking-tight text-white mt-1">Datos de tu Auto</h2>
              </div>
              <span className="text-xs bg-red-600/15 text-red-400 font-bold px-3 py-1 rounded-full flex items-center gap-1 border border-red-500/10">
                <TrendingUp className="w-3.5 h-3.5" /> Tasador Activo
              </span>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
              {/* Brand Selection */}
              <div>
                <label className="block text-xs font-bold text-white/60 uppercase mb-1.5">Marca</label>
                <select
                  value={brand}
                  onChange={(e) => {
                    setBrand(e.target.value);
                    const b = POPULAR_BRANDS.find(brandObj => brandObj.name === e.target.value);
                    if (b && b.models.length > 0) {
                      setModel(b.models[0]);
                    }
                  }}
                  className="w-full bg-zinc-900 border border-white/10 text-white rounded-xl px-4 py-3 text-sm focus:outline-hidden focus:border-red-500 focus:bg-zinc-800 transition-all"
                  id="brand_select"
                >
                  {POPULAR_BRANDS.map(b => (
                    <option key={b.name} value={b.name} className="bg-zinc-950">{b.name}</option>
                  ))}
                </select>
              </div>

              {/* Model Input */}
              <div>
                <label className="block text-xs font-bold text-white/60 uppercase mb-1.5">Modelo</label>
                <input
                  type="text"
                  value={model}
                  onChange={(e) => setModel(e.target.value)}
                  placeholder="Ej: Swift, Hilux, Accent"
                  className="w-full bg-zinc-900 border border-white/10 text-white rounded-xl px-4 py-3 text-sm focus:outline-hidden focus:border-red-500 focus:bg-zinc-800 transition-all"
                  id="model_input"
                  required
                />
              </div>

              {/* Year Select */}
              <div>
                <label className="block text-xs font-bold text-white/60 uppercase mb-1.5">Año</label>
                <select
                  value={year}
                  onChange={(e) => setYear(Number(e.target.value))}
                  className="w-full bg-zinc-900 border border-white/10 text-white rounded-xl px-4 py-3 text-sm focus:outline-hidden focus:border-red-500 focus:bg-zinc-800 transition-all"
                  id="year_select"
                >
                  {Array.from({ length: 17 }, (_, i) => 2026 - i).map(y => (
                    <option key={y} value={y} className="bg-zinc-950">{y}</option>
                  ))}
                </select>
              </div>

              {/* Kilometers Input */}
              <div>
                <label className="block text-xs font-bold text-white/60 uppercase mb-1.5">Kilometraje</label>
                <input
                  type="number"
                  value={km}
                  onChange={(e) => setKm(Math.max(0, Number(e.target.value)))}
                  className="w-full bg-zinc-900 border border-white/10 text-white rounded-xl px-4 py-3 text-sm focus:outline-hidden focus:border-red-500 focus:bg-zinc-800 transition-all"
                  id="km_input"
                  required
                />
              </div>

              {/* Fuel Type */}
              <div>
                <label className="block text-xs font-bold text-white/60 uppercase mb-1.5">Combustible</label>
                <div className="grid grid-cols-2 gap-2">
                  {(['Bencina', 'Diésel', 'Híbrido', 'Eléctrico'] as const).map(f => (
                    <button
                      key={f}
                      type="button"
                      onClick={() => setFuel(f)}
                      className={`py-2 px-3 text-xs font-bold rounded-lg border transition-all cursor-pointer ${
                        fuel === f 
                          ? 'border-red-600 bg-red-600/10 text-red-400' 
                          : 'border-white/10 bg-zinc-900 text-white/60 hover:bg-zinc-800'
                      }`}
                      id={`fuel_${f.toLowerCase()}_btn`}
                    >
                      {f}
                    </button>
                  ))}
                </div>
              </div>

              {/* Transmission Type */}
              <div>
                <label className="block text-xs font-bold text-white/60 uppercase mb-1.5">Transmisión</label>
                <div className="grid grid-cols-2 gap-2">
                  {(['Manual', 'Automática'] as const).map(t => (
                    <button
                      key={t}
                      type="button"
                      onClick={() => setTransmission(t)}
                      className={`py-2 px-3 text-xs font-bold rounded-lg border transition-all cursor-pointer ${
                        transmission === t 
                          ? 'border-red-600 bg-red-600/10 text-red-400' 
                          : 'border-white/10 bg-zinc-900 text-white/60 hover:bg-zinc-800'
                      }`}
                      id={`trans_${t.toLowerCase()}_btn`}
                    >
                      {t}
                    </button>
                  ))}
                </div>
              </div>
            </div>

            {/* Tasación Live Widget */}
            {valuation && (
              <div className="p-4 bg-white/5 border border-white/10 rounded-2xl mb-6 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                <div>
                  <div className="flex items-center gap-1.5 text-white/80 font-bold text-xs uppercase tracking-wider">
                    <DollarSign className="w-4 h-4 shrink-0 text-red-500" />
                    Valor de Mercado AutoMatch
                  </div>
                  <p className="text-2xl font-black font-sans text-white mt-1">
                    ${valuation.avgPrice.toLocaleString('es-CL')} CLP
                  </p>
                  <p className="text-xs text-white/50 mt-0.5">
                    Rango sugerido: ${valuation.lowPrice.toLocaleString('es-CL')} - ${valuation.highPrice.toLocaleString('es-CL')} CLP
                  </p>
                </div>
                
                <div className="border-t sm:border-t-0 sm:border-l border-white/10 sm:pl-4 pt-3 sm:pt-0 shrink-0 text-left">
                  <div className="text-white/40 text-[10px] uppercase font-bold tracking-wider">Demanda en Chile</div>
                  <div className="flex items-center gap-1.5 mt-1">
                    <span className={`w-2 h-2 rounded-full ${valuation.liquidityScore === 'Alta' ? 'bg-green-500 animate-ping' : valuation.liquidityScore === 'Media' ? 'bg-amber-500' : 'bg-red-500'}`}></span>
                    <span className="font-bold text-white/90 text-sm">Alta Demanda ({valuation.demandPercentage}%)</span>
                  </div>
                  <span className="text-xs text-white/40 block mt-0.5">Venta prom: {valuation.estimatedDaysToSell} días</span>
                </div>
              </div>
            )}

            {/* Set Selling Price */}
            <div className="mb-6">
              <label className="block text-xs font-bold text-white/60 uppercase mb-1.5">Tu Precio de Publicación (CLP)</label>
              <div className="relative">
                <span className="absolute left-4 top-1/2 -translate-y-1/2 text-white/40 font-bold">$</span>
                <input
                  type="number"
                  value={price}
                  onChange={(e) => setPrice(Number(e.target.value))}
                  placeholder="Ej: 9500000"
                  className="w-full bg-zinc-900 border border-white/10 text-white rounded-xl pl-8 pr-4 py-3 text-sm font-bold focus:outline-hidden focus:border-red-500 focus:bg-zinc-800 transition-all"
                  id="price_input"
                  required
                />
              </div>
              <p className="text-[11px] text-white/40 mt-1">
                *Puedes ajustarlo libremente. Un precio realista te dará más matches en Chile.
              </p>
            </div>

            <div className="flex gap-3">
              <button
                onClick={() => setStep(0)}
                className="flex-1 border border-white/10 hover:bg-white/5 text-white/75 font-semibold py-3 px-4 rounded-xl text-sm transition-all cursor-pointer"
                id="back_to_0_btn"
              >
                Atrás
              </button>
              <button
                onClick={() => setStep(2)}
                className="flex-1 bg-red-600 hover:bg-red-700 text-white font-bold py-3 px-4 rounded-xl text-sm transition-all flex items-center justify-center gap-1.5 cursor-pointer shadow-md shadow-red-600/10"
                id="to_step2_btn"
              >
                Siguiente
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          </motion.div>
        ) : step === 2 ? (
          /* PASO 2: SWAP/SELL PREFS */
          <motion.div 
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            className="w-full bg-[#141414] rounded-3xl p-6 md:p-8 border border-white/10 shadow-2xl"
            id="step2_card"
          >
            <div>
              <span className="text-xs font-bold text-red-500 uppercase tracking-wider">Paso 2 de 3</span>
              <h2 className="text-2xl font-sans font-black uppercase italic tracking-tight text-white mt-1 mb-6">¿Qué buscas con tu auto?</h2>
            </div>

            {/* Offer Type */}
            <div className="mb-6">
              <label className="block text-xs font-bold text-white/60 uppercase mb-2">Modalidad de negocio</label>
              <div className="grid grid-cols-2 gap-3">
                <button
                  type="button"
                  onClick={() => setPermuta(false)}
                  className={`p-4 rounded-xl border text-left transition-all cursor-pointer flex flex-col justify-between h-28 ${
                    !permuta 
                      ? 'border-red-600 bg-red-600/10 text-red-400 shadow-md' 
                      : 'border-white/10 bg-zinc-900 text-white/60 hover:bg-zinc-800'
                  }`}
                  id="mode_only_sale_btn"
                >
                  <DollarSign className="w-6 h-6 text-red-500" />
                  <div>
                    <h4 className="font-bold text-sm text-white">Solo Vender</h4>
                    <p className="text-xs text-white/50 mt-0.5">Busco ofertas de dinero directo por mi auto.</p>
                  </div>
                </button>

                <button
                  type="button"
                  onClick={() => setPermuta(true)}
                  className={`p-4 rounded-xl border text-left transition-all cursor-pointer flex flex-col justify-between h-28 ${
                    permuta 
                      ? 'border-red-600 bg-red-600/10 text-red-400 shadow-md' 
                      : 'border-white/10 bg-zinc-900 text-white/60 hover:bg-zinc-800'
                  }`}
                  id="mode_permuta_btn"
                >
                  <Compass className="w-6 h-6 text-red-500" />
                  <div>
                    <h4 className="font-bold text-sm text-white">Permutar o Vender</h4>
                    <p className="text-xs text-white/50 mt-0.5">Acepto intercambios por otros vehículos.</p>
                  </div>
                </button>
              </div>
            </div>

            {/* Permuta Preferences */}
            {permuta && (
              <motion.div 
                initial={{ opacity: 0, height: 0 }}
                animate={{ opacity: 1, height: 'auto' }}
                className="mb-6 overflow-hidden"
                id="permuta_pref_wrapper"
              >
                <label className="block text-xs font-bold text-white/60 uppercase mb-1.5">¿Qué tipo de auto buscas permutar?</label>
                <input
                  type="text"
                  value={permutaPreferences}
                  onChange={(e) => setPermutaPreferences(e.target.value)}
                  placeholder="Ej: Busco camioneta diésel de mayor año, pago diferencia"
                  className="w-full bg-zinc-900 border border-white/10 text-white rounded-xl px-4 py-3 text-sm focus:outline-hidden focus:border-red-500 focus:bg-zinc-800 transition-all"
                  id="permuta_prefs_input"
                  required={permuta}
                />
                <p className="text-[10px] text-white/40 mt-1">
                  *Sé específico en lo que aceptas (Ej: "Recibo menor valor + dinero" o "Doy diferencia").
                </p>
              </motion.div>
            )}

            {/* Description */}
            <div className="mb-6">
              <label className="block text-xs font-bold text-white/60 uppercase mb-1.5">Breve descripción de tu auto</label>
              <textarea
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                placeholder="Ej: Único dueño, neumáticos nuevos, excelente andar, aire acondicionado..."
                rows={3}
                className="w-full bg-zinc-900 border border-white/10 text-white rounded-xl px-4 py-3 text-sm focus:outline-hidden focus:border-red-500 focus:bg-zinc-800 transition-all resize-none"
                id="description_textarea"
                required
              />
            </div>

            <div className="flex gap-3">
              <button
                onClick={() => setStep(1)}
                className="flex-1 border border-white/10 hover:bg-white/5 text-white/75 font-semibold py-3 px-4 rounded-xl text-sm transition-all cursor-pointer"
                id="back_to_1_btn"
              >
                Atrás
              </button>
              <button
                onClick={() => setStep(3)}
                className="flex-1 bg-red-600 hover:bg-red-700 text-white font-bold py-3 px-4 rounded-xl text-sm transition-all flex items-center justify-center gap-1.5 cursor-pointer shadow-md shadow-red-600/10"
                id="to_step3_btn"
              >
                Siguiente
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          </motion.div>
        ) : (
          /* PASO 3: CONTACT & PRESETS */
          <motion.div 
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            className="w-full bg-[#141414] rounded-3xl p-6 md:p-8 border border-white/10 shadow-2xl"
            id="step3_card"
          >
            <form onSubmit={handleSubmit}>
              <div>
                <span className="text-xs font-bold text-red-500 uppercase tracking-wider">Paso 3 de 3</span>
                <h2 className="text-2xl font-sans font-black uppercase italic tracking-tight text-white mt-1 mb-6">Tus datos y foto del auto</h2>
              </div>

              {/* User Name */}
              <div className="mb-4">
                <label className="block text-xs font-bold text-white/60 uppercase mb-1.5">Tu Nombre de Vendedor / Permutador</label>
                <input
                  type="text"
                  value={userName}
                  onChange={(e) => setUserName(e.target.value)}
                  placeholder="Ej: Alexis Ganer"
                  className="w-full bg-zinc-900 border border-white/10 text-white rounded-xl px-4 py-3 text-sm focus:outline-hidden focus:border-red-500 focus:bg-zinc-800 transition-all"
                  id="user_name_input"
                  required
                />
              </div>

              {/* Contact Phone */}
              <div className="mb-4">
                <label className="block text-xs font-bold text-white/60 uppercase mb-1.5">Tu Celular o WhatsApp de contacto</label>
                <input
                  type="tel"
                  value={contactPhone}
                  onChange={(e) => setContactPhone(e.target.value)}
                  placeholder="Ej: +56 9 1234 5678"
                  className="w-full bg-zinc-900 border border-white/10 text-white rounded-xl px-4 py-3 text-sm focus:outline-hidden focus:border-red-500 focus:bg-zinc-800 transition-all"
                  id="user_phone_input"
                  required
                />
              </div>

              {/* Region and Commune selection */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mb-6">
                <div>
                  <label className="block text-xs font-bold text-white/60 uppercase mb-1.5">Región</label>
                  <select
                    value={region}
                    onChange={(e) => setRegion(e.target.value)}
                    className="w-full bg-zinc-900 border border-white/10 text-white rounded-xl px-4 py-3 text-sm focus:outline-hidden focus:border-red-500"
                    id="region_select"
                  >
                    {CHILEAN_REGIONS.map(r => (
                      <option key={r.name} value={r.name} className="bg-zinc-950">{r.name}</option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="block text-xs font-bold text-white/60 uppercase mb-1.5">Comuna</label>
                  <select
                    value={commune}
                    onChange={(e) => setCommune(e.target.value)}
                    className="w-full bg-zinc-900 border border-white/10 text-white rounded-xl px-4 py-3 text-sm focus:outline-hidden focus:border-red-500"
                    id="commune_select"
                  >
                    {communesList.map(c => (
                      <option key={c} value={c} className="bg-zinc-950">{c}</option>
                    ))}
                  </select>
                </div>
              </div>

              {/* Photo Upload from Gallery */}
              <div className="mb-5">
                <label className="block text-xs font-bold text-white/60 uppercase mb-3">Sube una foto real de tu auto (recomendado)</label>
                <div className="flex items-center gap-4">
                  <label
                    htmlFor="photo_upload_input"
                    className={`relative w-24 h-24 shrink-0 rounded-xl overflow-hidden border-2 cursor-pointer transition-all ${
                      isUploadedPhoto
                        ? 'border-red-600 ring-3 ring-red-500/20 shadow-md'
                        : 'border-dashed border-white/20 hover:border-red-500/60 bg-zinc-900'
                    }`}
                    id="photo_upload_preview_label"
                  >
                    {isUploadedPhoto ? (
                      <img
                        src={selectedPhoto}
                        alt="Foto subida"
                        className="w-full h-full object-cover"
                      />
                    ) : (
                      <div className="w-full h-full flex flex-col items-center justify-center gap-1 text-white/40">
                        <ImagePlus className="w-6 h-6" />
                      </div>
                    )}
                  </label>
                  <div className="flex-1">
                    <input
                      type="file"
                      accept="image/*"
                      onChange={handlePhotoUpload}
                      className="hidden"
                      id="photo_upload_input"
                    />
                    <label
                      htmlFor="photo_upload_input"
                      className="inline-flex items-center gap-1.5 bg-red-600 hover:bg-red-700 text-white font-bold py-2.5 px-4 rounded-xl text-xs transition-all cursor-pointer shadow-md shadow-red-600/10"
                      id="photo_upload_trigger_btn"
                    >
                      <Upload className="w-3.5 h-3.5" />
                      {isUploadedPhoto ? 'Cambiar foto' : 'Elegir de mi galería'}
                    </label>
                    <p className="text-[10px] text-white/40 mt-1.5">
                      Formatos JPG, PNG o WEBP · Máx. 8MB.
                    </p>
                    {uploadError && (
                      <p className="text-[10px] text-red-400 font-semibold mt-1">{uploadError}</p>
                    )}
                  </div>
                </div>
              </div>

              {/* Photo Presets */}
              <div className="mb-6">
                <label className="block text-xs font-bold text-white/60 uppercase mb-3">
                  O elige una foto de referencia
                </label>
                <div className="grid grid-cols-2 sm:grid-cols-5 gap-2.5">
                  {PHOTO_PRESETS.map((p) => (
                    <button
                      key={p.id}
                      type="button"
                      onClick={() => {
                        setSelectedPhoto(p.url);
                        setIsUploadedPhoto(false);
                        setUploadError('');
                      }}
                      className={`relative aspect-square rounded-xl overflow-hidden border-2 transition-all cursor-pointer ${
                        selectedPhoto === p.url && !isUploadedPhoto
                          ? 'border-red-600 scale-95 ring-3 ring-red-500/20 shadow-md' 
                          : 'border-transparent opacity-50 hover:opacity-100 hover:scale-[1.02]'
                      }`}
                      id={`photo_preset_${p.id}`}
                    >
                      <img 
                        src={p.url} 
                        alt={p.name} 
                        className="w-full h-full object-cover"
                        referrerPolicy="no-referrer"
                      />
                      <div className="absolute inset-x-0 bottom-0 bg-black/80 py-1 text-[8px] font-bold text-white text-center truncate px-1">
                        {p.name.split(' ')[0]}
                      </div>
                    </button>
                  ))}
                </div>
              </div>

              <div className="flex gap-3">
                <button
                  type="button"
                  onClick={() => setStep(2)}
                  className="flex-1 border border-white/10 hover:bg-white/5 text-white/75 font-semibold py-3 px-4 rounded-xl text-sm transition-all cursor-pointer"
                  id="back_to_2_btn"
                >
                  Atrás
                </button>
                <button
                  type="submit"
                  className="flex-1 bg-red-600 hover:bg-red-700 text-white font-bold py-3 px-4 rounded-xl text-sm transition-all flex items-center justify-center gap-1.5 cursor-pointer shadow-lg shadow-red-600/30"
                  id="complete_onboarding_btn"
                >
                  ¡Ingresar y Deslizar!
                  <Sparkles className="w-4 h-4" />
                </button>
              </div>
            </form>
          </motion.div>
        )}
      </main>

      {/* Footer info to assure clients */}
      <footer className="py-4 text-center text-white/40 text-xs border-t border-white/10 bg-[#0f0f0f]" id="onboarding_footer">
        <div className="flex items-center justify-center gap-1.5">
          <ShieldCheck className="w-4 h-4 text-green-500" />
          <span>Información de autos y valorizaciones referenciales para el mercado chileno.</span>
        </div>
      </footer>
    </div>
  );
}
